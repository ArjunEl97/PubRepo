import datetime
from datetime import datetime, timedelta, date
import pandas as pd
from dateutil import parser
from dateutil import tz

#Auto-detect zones:
from_zone = tz.tzutc()
to_zone = tz.tzlocal()
#Convert time to IST and remove Offset
def convert_time_format(given_time):
    ist_time = ((given_time.split(".",1)[0]).replace("T"," ")).replace("Z","")
    utc = datetime.strptime(ist_time, '%Y-%m-%d %H:%M:%S')
    utc = utc.replace(tzinfo=from_zone)
    ist_time = utc.astimezone(to_zone)
    ist_time = ist_time.replace(tzinfo=None)
    return ist_time

#Python's program to convert number of days, hours, minutes and seconds to seconds.
def convert_to_seconds(given_date_and_time):  
    #Define the constants
    SECONDS_PER_MINUTE  = 60
    SECONDS_PER_HOUR    = 3600
    SECONDS_PER_DAY     = 86400
    total_seconds = 0
    #Calculate the days, hours, minutes and seconds
    if "day" in str(given_date_and_time):
        day = str(given_date_and_time).split("day")[0].strip()
        time = str(given_date_and_time).split(",")[1].strip()
        hours = str(time).split(":")[0].strip()
        minutes = str(time).split(":")[1].strip()
        seconds = str(time).split(":")[2].strip()
        total_seconds = int(day) * SECONDS_PER_DAY
        total_seconds = total_seconds + ( int(hours) * SECONDS_PER_HOUR)
        total_seconds = total_seconds + ( int(minutes) * SECONDS_PER_MINUTE)
        total_seconds = total_seconds + int(seconds)
    else:
        hours = str(given_date_and_time).split(":")[0].strip()
        minutes = str(given_date_and_time).split(":")[1].strip()
        seconds = str(given_date_and_time).split(":")[2].strip()
        total_seconds = total_seconds + ( int(hours) * SECONDS_PER_HOUR)
        total_seconds = total_seconds + ( int(minutes) * SECONDS_PER_MINUTE)
        total_seconds = total_seconds + int(seconds)
    print("Total number of seconds: ","%d"%(total_seconds))
    return total_seconds

def get_queue_item_processing_data(QueueDF,QueueItemDF,ProcessDF,process_name):
    data  = pd.DataFrame([])
    # Sort the rows of dataframe by 'StartProcessing' column
    QueueItemDF = QueueItemDF.sort_values(by = 'StartProcessing', ascending = False)
    print(QueueItemDF)
    #QueueItemDF.to_excel(str("QueueItemSorted.xlsx"),index=False)
    for Process in ProcessDF.index:
        ProcessKey = ProcessDF['ProcessKey'][Process]
        ProcessId = ProcessDF['Id'][Process]
        if process_name==ProcessKey:
            for Queue in QueueDF.index:
                ReleaseId = QueueDF['ReleaseId'][Queue]
                QueueId = QueueDF['Id'][Queue]
                print("Release ID: " + str(ReleaseId))
                if ProcessId==ReleaseId:
                    TAKEN_QUEUE_ITEMS = 0
                    for QueueItem in QueueItemDF.index:
                        QueueDefinitionId = QueueItemDF['QueueDefinitionId'][QueueItem]
                        QueueItemStatus = QueueItemDF['Status'][QueueItem]
                        QueueItemId = QueueItemDF['Id'][QueueItem]
                        QueueItemStartTime = QueueItemDF['StartProcessing'][QueueItem]
                        QueueItemEndTime = QueueItemDF['EndProcessing'][QueueItem]
                        print("QueueItemId:" + str(QueueItemId))
                        if (QueueId==QueueDefinitionId and QueueItemStatus=="Successful" and TAKEN_QUEUE_ITEMS < 10):
                            TAKEN_QUEUE_ITEMS = TAKEN_QUEUE_ITEMS + 1
                            QueueItemProcessingTime = 0
                            QueueItemStartTime = convert_time_format(QueueItemStartTime)
                            QueueItemEndTime = convert_time_format(QueueItemEndTime)
                            QueueItemProcessingTime = QueueItemEndTime - QueueItemStartTime
                            print(QueueItemStartTime)
                            print(QueueItemEndTime)              
                            print(QueueItemProcessingTime)
                            print(TAKEN_QUEUE_ITEMS)
                            QueueItemProcessingTime = convert_to_seconds(QueueItemProcessingTime)
                            data = data.append(pd.DataFrame({'QueueItem': QueueItemId, 'Processing Time': QueueItemProcessingTime}, index=[0]), ignore_index=True)
                            print(data)
    return data