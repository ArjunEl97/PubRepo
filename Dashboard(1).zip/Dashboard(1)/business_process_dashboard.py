import datetime
from datetime import datetime, timedelta, date
import pandas as pd
from dateutil import parser
from dateutil import tz
import get_orchestrator_filtered_job_details
import get_orchestrator_process_details
import get_orchestrator_queue_status_details
import get_orchestrator_filtered_queue_item_details

import read_json_file
import get_access_token
import get_orchestrator_folders_details
import get_folder_id

#Auto-detect zones:
from_zone = tz.tzutc()
to_zone = tz.tzlocal()
#Convert time to IST and remove Offset
def convert_time_format(given_time):
    ist_time = ((given_time.rsplit(":",1)[0]).replace("T"," ")).replace("Z","")
    utc = datetime.strptime(ist_time, '%Y-%m-%d %H:%M')
    utc = utc.replace(tzinfo=from_zone)
    ist_time = utc.astimezone(to_zone)
    ist_time = ist_time.replace(tzinfo=None)
    return ist_time
def convert_seconds_to_day(second):
    day = second // (24 * 3600)
    second = second % (24 * 3600)
    hour = second // 3600
    second %= 3600
    minutes = second // 60
    second %= 60
    seconds = second
    print("%d day, %d:%02d:%02d" % (day, hour, minutes, seconds))
    return "%d day, %d:%02d:%02d" % (day, hour, minutes, seconds)
def add_days(given_date_time):
    day_count = str(given_date_time).split("day")[0].strip()
    calcuated_time = str(given_date_time).split(",")[1].strip()
    calculated_date = date.today().day + int(day_count)
    print("Calculated Date: " + str(calculated_date))
    projected_end_time = str(date.today().year) + "-" + str(date.today().month) + "-" + str(calculated_date) + " " + calcuated_time
    print("Final Date and Time:" + projected_end_time)
    return projected_end_time
def business_process_dashboard(start_time):
    #Create Dataframe
    ConfigData = dict()
    access_token = "a"
    FolderId = "b"
    data  = pd.DataFrame([])
    FoldersDF  = pd.DataFrame([])
    JobDF  = pd.DataFrame([])
    ProcessDF = pd.DataFrame([])
    QueueDF = pd.DataFrame([])
    QueueItemDF = pd.DataFrame([])
    QueueItemProcessingTimeDF = pd.DataFrame([]) 
    ConfigData = read_json_file.read_json()
    access_token = get_access_token.get_access_token(ConfigData)
    FoldersDF = get_orchestrator_folders_details.get_all_folder_details(ConfigData,access_token)
    FolderId = get_folder_id.get_folder_id(ConfigData,FoldersDF)
    ProcessDF = get_orchestrator_process_details.get_processes(ConfigData,access_token,FolderId)
    QueueDF = get_orchestrator_queue_status_details.get_queue_details(ConfigData,access_token,FolderId)
    JobDF = get_orchestrator_filtered_job_details.get_filtered_jobs(ConfigData,access_token,FolderId,start_time)
    if not (JobDF.empty):
        QueueItemDF = get_orchestrator_filtered_queue_item_details.get_filtered_queue_items(ConfigData,access_token,FolderId,JobDF,ProcessDF,QueueDF)
        #Get Unique Jobs
        UniqueJobs = JobDF.ReleaseName.unique()
        print(UniqueJobs)
        for UniqueJob in UniqueJobs:
            ITERATION_COUNTER = 1
            print(UniqueJob)
            for Job in JobDF.index:
                ReleaseName = JobDF['ReleaseName'][Job]
                JobCreationTime = JobDF['CreationTime'][Job]
                JobCreationTime = convert_time_format(JobCreationTime)
                if ITERATION_COUNTER == 1:
                    UniqueueJobCreationTime = JobCreationTime
                    JobState = JobDF['State'][Job]
                    JobEndTime = JobDF['EndTime'][Job]
                if(ReleaseName == UniqueJob and UniqueueJobCreationTime < JobCreationTime):
                    UniqueueJobCreationTime = JobCreationTime
                    JobState = JobDF['State'][Job]
                    JobEndTime = JobDF['EndTime'][Job]
                ITERATION_COUNTER = ITERATION_COUNTER + 1
            print(UniqueueJobCreationTime)
            if JobEndTime is not None:
                JobEndTime = convert_time_format(JobEndTime)
            TOTAL_QUEUE_ITEMS = 0
            COMPLETED_QUEUE_ITEMS = 0
            NEW_STATE_QUEUE_ITEMS = 0
            PROJECTED_END_TIME = 0
            OVERSHOOT = 0
            Process = ""
            PROGRESS = ""
            for Process in ProcessDF.index:
                ProcessKey = ProcessDF['ProcessKey'][Process]
                ProcessId = ProcessDF['Id'][Process]
                if UniqueJob==ProcessKey:
                    for Queue in QueueDF.index:
                        ReleaseId = QueueDF['ReleaseId'][Queue]
                        QueueId = QueueDF['Id'][Queue]
                        AverageProcessingTime = QueueDF['ProcessingMeanTime'][Queue]
                        if ProcessId==ReleaseId:
                            for QueueItem in QueueItemDF.index:
                                QueueDefinitionId = QueueItemDF['QueueDefinitionId'][QueueItem]
                                QueueItemId = QueueItemDF['Id'][QueueItem]
                                QueueItemStatus = QueueItemDF['Status'][QueueItem]
                                if QueueId==QueueDefinitionId:
                                    TOTAL_QUEUE_ITEMS = TOTAL_QUEUE_ITEMS + 1
                                    if QueueItemStatus == "New":
                                        NEW_STATE_QUEUE_ITEMS = NEW_STATE_QUEUE_ITEMS + 1
                            COMPLETED_QUEUE_ITEMS = TOTAL_QUEUE_ITEMS - NEW_STATE_QUEUE_ITEMS
                            PROGRESS = str(COMPLETED_QUEUE_ITEMS) + '/' + str(TOTAL_QUEUE_ITEMS)
                            if JobEndTime is not None:
                                PROJECTED_END_TIME = JobEndTime
                            else:
                                print("Average Processing Time: " + str(AverageProcessingTime))
                                print("New State Queue Items" + str(NEW_STATE_QUEUE_ITEMS))
                                RequiredTimeForCompletionSeconds = AverageProcessingTime * NEW_STATE_QUEUE_ITEMS
                                print("Required Time For Completion in Seconds: " + str(RequiredTimeForCompletionSeconds))
                                RequiredTimeForCompletion = convert_seconds_to_day(RequiredTimeForCompletionSeconds)
                                print("Required Time For Completion: " + str(RequiredTimeForCompletion))
                                RequiredTimeForCompletion = add_days(RequiredTimeForCompletion)
                                RequiredTimeForCompletion = parser.parse(RequiredTimeForCompletion)
                                print("Required Time For Completion with date: " +str(RequiredTimeForCompletion))
                                CurrentTime = datetime.now()
                                print("Current Time: " + str(CurrentTime))
                                PROJECTED_END_TIME = timedelta(hours=int(CurrentTime.hour),minutes=int(CurrentTime.minute),seconds=int(CurrentTime.second),microseconds=int(CurrentTime.microsecond)) + timedelta(hours=int(RequiredTimeForCompletion.hour),minutes=int(RequiredTimeForCompletion.minute),seconds=int(RequiredTimeForCompletion.second),microseconds=int(RequiredTimeForCompletion.microsecond))
                                if 'day' in str(PROJECTED_END_TIME):
                                    PROJECTED_END_TIME = add_days(PROJECTED_END_TIME)
                                PROJECTED_END_TIME = parser.parse(str(PROJECTED_END_TIME))
                            if JobState == "Running":
                                if CurrentTime > PROJECTED_END_TIME:
                                    OVERSHOOT = CurrentTime - PROJECTED_END_TIME
                                    OVERSHOOT = str(OVERSHOOT).rsplit(":",1)[0].strip()
                            PROJECTED_END_TIME = str(PROJECTED_END_TIME).rsplit(":",1)[0].strip()
                            print("Process: " + UniqueJob)
                            print("Status: " + JobState)
                            print("Projected End Time: " + str(PROJECTED_END_TIME))
                            #print("Items: " + str(TOTAL_QUEUE_ITEMS))
                            print("OVERSHOOT:" + str(OVERSHOOT))
                            print("Progress: " + PROGRESS)
                            data = data.append(pd.DataFrame({'Process': UniqueJob, 'Projected End Time': PROJECTED_END_TIME, 'Overshoot': OVERSHOOT, 'Status': JobState, 'Progress': PROGRESS, 'Graph': UniqueJob}, index=[0]), ignore_index=True)
                            print(data.to_string(index=False))
    #data.to_excel(str("BusinessProcessDashboard.xlsx"),index=False)
    return data, ConfigData, access_token, FolderId, QueueDF, ProcessDF