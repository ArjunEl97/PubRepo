import json
def read_json():
    # Opening JSON file
    f = open(r"BusinessProcessDashboardInputFile.json", 'r')
    # returns JSON object as a dictionary
    data = json.load(f)
    ConfigData = dict()
    ConfigData["Client_Id"] = data["Client_Id"]
    ConfigData["Refresh_Token"] = data["Refresh_Token"]
    ConfigData["URL"] = data["URL"]
    ConfigData["Folder_Name"] = data["Folder_Name"]
    print(ConfigData)
    print(ConfigData["Client_Id"])
    print(ConfigData["Refresh_Token"])
    print(ConfigData["URL"])
    print(ConfigData["Folder_Name"])
    # Closing file
    f.close()
    return ConfigData
