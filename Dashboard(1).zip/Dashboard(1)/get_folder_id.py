def get_folder_id(ConfigData,FoldersDF):
    for Folder in FoldersDF.index:
        FolderName = FoldersDF['FullyQualifiedName'][Folder]
        if FolderName == ConfigData["Folder_Name"]:
            FolderId = FoldersDF['Id'][Folder]
            break
    print(FolderId)
    return FolderId
