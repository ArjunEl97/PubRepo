import requests
import pandas as pd
import flatten_json_data
def get_all_folder_details(ConfigData,access_token):
    url = ConfigData["URL"] + "folders"
    payload={}
    headers = {
    'Authorization': "Bearer "+ access_token
        }
    FoldersResponse = requests.request("GET", url, headers=headers, data=payload)
    #Convert to Json format
    json_FoldersResponse = FoldersResponse.json()
    #Get the Value from Json Data
    json_FoldersData = json_FoldersResponse['value']
    #Flatten Json Data
    FoldersDF  = pd.DataFrame([])
    FoldersDF = flatten_json_data.json_to_dataframe(json_FoldersData)
    print(FoldersResponse.text)
    print(json_FoldersData)
    print(FoldersDF)
    #FoldersDF.to_excel("GetOrchestratorFoldersDetails.xlsx")
    return FoldersDF
