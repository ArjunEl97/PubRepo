from datetime import datetime, timedelta
import requests
import pandas as pd
from dateutil import parser
from dateutil import tz
import flatten_json_data
#import business_process_dashboard

#Auto-detect zones:
from_zone = tz.tzutc()
to_zone = tz.tzlocal()

#Convert time to IST and remove Offset with considering seconds
def convert_time_format(given_time):
    ist_time = ((given_time.split(".",1)[0]).replace("T"," ")).replace("Z","")
    utc = datetime.strptime(ist_time, '%Y-%m-%d %H:%M:%S')
    utc = utc.replace(tzinfo=from_zone)
    ist_time = utc.astimezone(to_zone)
    ist_time = ist_time.replace(tzinfo=None)
    return ist_time

#Python's program to convert number of days, hours, minutes and seconds to seconds.
def convert_to_seconds(given_date_and_time):  
    #Define the constants
    SECONDS_PER_MINUTE  = 60
    SECONDS_PER_HOUR    = 3600
    SECONDS_PER_DAY     = 86400
    total_seconds = 0
    #Calculate the days, hours, minutes and seconds
    if "day" in str(given_date_and_time):
        day = str(given_date_and_time).split("day")[0].strip()
        time = str(given_date_and_time).split(",")[1].strip()
        hours = str(time).split(":")[0].strip()
        minutes = str(time).split(":")[1].strip()
        seconds = str(time).split(":")[2].strip()
        total_seconds = int(day) * SECONDS_PER_DAY
        total_seconds = total_seconds + ( int(hours) * SECONDS_PER_HOUR)
        total_seconds = total_seconds + ( int(minutes) * SECONDS_PER_MINUTE)
        total_seconds = total_seconds + int(seconds)
    else:
        hours = str(given_date_and_time).split(":")[0].strip()
        minutes = str(given_date_and_time).split(":")[1].strip()
        seconds = str(given_date_and_time).split(":")[2].strip()
        total_seconds = total_seconds + ( int(hours) * SECONDS_PER_HOUR)
        total_seconds = total_seconds + ( int(minutes) * SECONDS_PER_MINUTE)
        total_seconds = total_seconds + int(seconds)
    print("Total number of seconds: ","%d"%(total_seconds))
    return total_seconds

def get_filtered_queue_items(ConfigData, access_token, FolderId, QueueDF, ProcessDF, Process_Name):
    #Payload and headers
    payload={}
    headers = {
      'X-UIPATH-OrganizationUnitId': str(FolderId),
      'Authorization': "Bearer "+ access_token
    }
    data  = pd.DataFrame([])
    for Process in ProcessDF.index:
        ProcessKey = ProcessDF['ProcessKey'][Process]
        ProcessId = ProcessDF['Id'][Process]
        if Process_Name == ProcessKey:
            for Queue in QueueDF.index:
                ReleaseId = QueueDF['ReleaseId'][Queue]
                QueueId = QueueDF['Id'][Queue]
                print("Release ID: " + str(ReleaseId))
                if ProcessId==ReleaseId:
                    #Create Dataframe
                    QueueItemDF = pd.DataFrame([])
                    url = ConfigData["URL"] + "QueueItems?$top=10&$orderby=CreationTime desc&$filter=(Status eq 'Successful' and QueueDefinitionId eq " +str(QueueId)+")"
                    QueueItemResponse = requests.request("GET", url, headers=headers, data=payload)
                    #Convert to Json format
                    print(QueueItemResponse.text)
                    json_QueueItemResponse = QueueItemResponse.json()
                    #Get the Value from Json Data
                    print(QueueItemResponse.text)
                    json_QueueItemData = json_QueueItemResponse['value']
                    #Flatten Json Data
                    QueueItemDF = QueueItemDF.append(flatten_json_data.json_to_dataframe(json_QueueItemData),ignore_index=True)
                    QueueItemDF.to_excel(str("QueueItemSorted.xlsx"),index=False)
                    print(QueueItemResponse.text)
                    print(QueueItemResponse.text)
                    print(json_QueueItemData)
                    print(QueueItemDF)
                    for QueueItem in QueueItemDF.index:
                        QueueDefinitionId = QueueItemDF['QueueDefinitionId'][QueueItem]
                        QueueItemStatus = QueueItemDF['Status'][QueueItem]
                        QueueItemId = QueueItemDF['Id'][QueueItem]
                        QueueItemStartTime = QueueItemDF['StartProcessing'][QueueItem]
                        QueueItemEndTime = QueueItemDF['EndProcessing'][QueueItem]
                        print("QueueItemId:" + str(QueueItemId))
                        QueueItemProcessingTime = 0
                        print(QueueItemStartTime)
                        print(QueueItemEndTime)
                        QueueItemStartTime = convert_time_format(QueueItemStartTime)
                        QueueItemEndTime = convert_time_format(QueueItemEndTime)
                        QueueItemProcessingTime = QueueItemEndTime - QueueItemStartTime
                        print(QueueItemStartTime)
                        print(QueueItemEndTime)              
                        print(QueueItemProcessingTime)
                        QueueItemProcessingTime = convert_to_seconds(QueueItemProcessingTime)
                        data = data.append(pd.DataFrame({'QueueItem': QueueItemId, 'Processing Time': QueueItemProcessingTime}, index=[0]), ignore_index=True)
                        print(data)
    return data

#process_data, ConfigData, access_token, FolderId, QueueDF, ProcessDF = business_process_dashboard.business_process_dashboard("250")
#get_filtered_queue_items(ConfigData, access_token, FolderId, QueueDF, ProcessDF, "QueuePOC4")

