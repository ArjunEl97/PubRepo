from datetime import datetime, timedelta
import requests
import pandas as pd
from dateutil import parser
from dateutil import tz
import flatten_json_data
#Auto-detect zones:
from_zone = tz.tzutc()
to_zone = tz.tzlocal()
#Convert time to IST and remove Offset
def convert_time_format(given_time):
    ist_time = ((given_time.rsplit(":",1)[0]).replace("T"," ")).replace("Z","")
    utc = datetime.strptime(ist_time, '%Y-%m-%d %H:%M')
    utc = utc.replace(tzinfo=from_zone)
    ist_time = utc.astimezone(to_zone)
    ist_time = ist_time.replace(tzinfo=None)
    return ist_time
def get_filtered_queue_items(ConfigData,access_token,FolderId,JobDF,ProcessDF,QueueDF):
    #Payload and headers
    payload={}
    headers = {
      'X-UIPATH-OrganizationUnitId': str(FolderId),
      'Authorization': "Bearer "+ access_token
    }
    #Create Dataframe
    QueueItemDF = pd.DataFrame([])
    #Get Unique Jobs
    UniqueJobs = JobDF.ReleaseName.unique()
    print(UniqueJobs)
    for UniqueJob in UniqueJobs:
        ITERATION_COUNTER = 1
        print(UniqueJob)
        for Job in JobDF.index:
            ReleaseName = JobDF['ReleaseName'][Job]
            JobCreationTime = JobDF['CreationTime'][Job]
            JobCreationTimeIST = convert_time_format(JobCreationTime)
            if ITERATION_COUNTER == 1:
                UniqueueJobCreationTime = JobCreationTime.rsplit(":",1)[0] + ":00.000Z"
                UniqueueJobCreationTimeIST = JobCreationTimeIST
            if(ReleaseName == UniqueJob and UniqueueJobCreationTimeIST < JobCreationTimeIST):
                UniqueueJobCreationTime = JobCreationTime.rsplit(":",1)[0] + ":00.000Z"
                UniqueueJobCreationTimeIST = JobCreationTimeIST
            ITERATION_COUNTER = ITERATION_COUNTER + 1
        print(UniqueueJobCreationTime)
        print(UniqueueJobCreationTimeIST)
        for Process in ProcessDF.index:
            ProcessKey = ProcessDF['ProcessKey'][Process]
            ProcessId = ProcessDF['Id'][Process]
            if UniqueJob==ProcessKey:
                for Queue in QueueDF.index:
                    ReleaseId = QueueDF['ReleaseId'][Queue]
                    QueueId = QueueDF['Id'][Queue]
                    if ProcessId==ReleaseId:
                        #Get QueueItem Details with Filter
                        print(QueueId)
                        print(UniqueueJobCreationTime)
                        url = ConfigData["URL"] + "QueueItems()?$Filter=QueueDefinitionId eq " + str(QueueId) + "AND CreationTime ge " + UniqueueJobCreationTime
                        QueueItemResponse = requests.request("GET", url, headers=headers, data=payload)
                        #Convert to Json format
                        json_QueueItemResponse = QueueItemResponse.json()
                        #Get the Value from Json Data
                        json_QueueItemData = json_QueueItemResponse['value']
                        #Flatten Json Data
                        QueueItemDF = QueueItemDF.append(flatten_json_data.json_to_dataframe(json_QueueItemData),ignore_index=True)
                        print(QueueItemResponse.text)
                        print(QueueItemResponse.text)
                        print(json_QueueItemData)
                        print(QueueItemDF)
    #QueueItemDF.to_excel("GetOrchestratorFilteredQueueItemDetails.xlsx")
    return QueueItemDF
