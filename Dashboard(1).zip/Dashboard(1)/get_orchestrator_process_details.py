import requests
import pandas as pd
import flatten_json_data
def get_processes(ConfigData,access_token,FolderId):
    #Get Process Details
    url = ConfigData["URL"] + "Releases"
    payload={}
    headers = {
      'X-UIPATH-TenantName': 'DefaultTenant',
      'X-UIPATH-OrganizationUnitId': str(FolderId),
      'Authorization': "Bearer "+ access_token
    }
    ProcessResponse = requests.request("GET", url, headers=headers, data=payload)
    #Convert to Json format
    json_ProcessResponse = ProcessResponse.json()
    #Get the Value from Json Data
    json_ProcessData = json_ProcessResponse['value']
    #Flatten Json Data
    ProcessDF = pd.DataFrame([])
    ProcessDF = flatten_json_data.json_to_dataframe(json_ProcessData)
    print(ProcessResponse.text)
    print(json_ProcessData)
    print(ProcessDF)
    #ProcessDF.to_excel("GetOrchestratorProcessDetails.xlsx")
    return ProcessDF
