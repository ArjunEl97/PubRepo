import requests
import pandas as pd
import flatten_json_data
def get_queue_details(ConfigData,access_token,FolderId):
    print(FolderId)
    #Get Queue Status
    url = ConfigData["URL"] +  "QueueProcessingRecords/UiPathODataSvc.RetrieveQueuesProcessingStatus"
    payload={}
    headers = {
      'X-UIPATH-OrganizationUnitId': str(FolderId),
      'Authorization': "Bearer "+ access_token
    }
    QueueResponse = requests.request("GET", url, headers=headers, data=payload)
    #Convert to Json format
    json_QueueResponse = QueueResponse.json()
    #Get the Value from Json Data
    json_QueueData = json_QueueResponse['value']
    #Flatten Json Data
    QueueDF = pd.DataFrame([])
    QueueDF = flatten_json_data.json_to_dataframe(json_QueueData)
    print(QueueResponse.text)
    print(json_QueueData)
    print(QueueDF)
    #QueueDF.to_excel("GetOrchestratorQueueStatusDetails.xlsx")
    return QueueDF
