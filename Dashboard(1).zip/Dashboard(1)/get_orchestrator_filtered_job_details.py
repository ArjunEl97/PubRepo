import sys
import pandas as pd
from datetime import datetime, timedelta
import requests
from dateutil import tz
import flatten_json_data
#Auto-detect zones:
from_zone = tz.tzlocal()
to_zone = tz.tzutc()
#Convert start time to UTC
def convert_time_format(given_time):
    ist = datetime.strptime(str(given_time).rsplit(":",1)[0], '%Y-%m-%d %H:%M')
    ist = ist.replace(tzinfo=from_zone)
    utc_time = ist.astimezone(to_zone)
    utc_time = utc_time.replace(tzinfo=None)
    return utc_time
def get_filtered_jobs(ConfigData,access_token,FolderId,start_time):
    InputStartTime = start_time
    print("Input time: " + InputStartTime)
    #Get the Start Time for filtering (Subtract the input argument from the current time)
    StartTime = datetime.today() - timedelta(hours=int(InputStartTime))
    print("Current time: " + str(datetime.today()))
    print("Current time: " + str(StartTime))
    StartTime = convert_time_format(StartTime)
    StartTime = (str(StartTime).replace(" ", "T")).rsplit(":",1)[0] + ":00.000Z"
    print(StartTime)
    #Get Job Details
    url = ConfigData["URL"] + "Jobs?$Filter=CreationTime ge " + StartTime
    payload={}
    headers = {
      'X-UIPATH-TenantName': 'DefaultTenant',
      'X-UIPATH-OrganizationUnitId': str(FolderId),
      'Authorization': "Bearer "+ access_token
    }
    JobResponse = requests.request("GET", url, headers=headers, data=payload)
    #Convert to Json format
    json_JobResponse = JobResponse.json()
    #Get the Value from Json Data
    json_JobData = json_JobResponse['value']
    #Flatten Json Data
    JobDF  = pd.DataFrame([])
    JobDF = flatten_json_data.json_to_dataframe(json_JobData)
    print(JobResponse.text)
    print(JobResponse.text)
    print(json_JobData)
    print(JobDF)
    #JobDF.to_excel("GetOrchestratorFilteredJobDetails.xlsx")
    return JobDF
