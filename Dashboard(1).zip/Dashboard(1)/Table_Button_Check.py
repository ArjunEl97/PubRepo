import streamlit as st
import pandas as pd
import business_process_dashboard
import get_orchestrator_filtered_queue_items_processing_time
import plotly.express as px
def custom_css(file_path:str):
    with open(file_path) as f:
        st.markdown("<style>{}</style>".format(f.read()),unsafe_allow_html = True)

custom_css(r"DashboardCss.css")
# # Show users table 
colms = st.columns((2, 2, 2, 2, 2, 2))
fields = ['Process', 'Projected End Time', 'Overshoot', 'Status', 'Progress', 'Graph']
for col, field_name in zip(colms, fields):
    # header
    col.write(field_name)

process_data, QueueDF, QueueItemDF, ProcessDF = business_process_dashboard.business_process_dashboard("250")
#data = [["QueuePOC1","2022-10-10 11:39","0","Running","1/13","QueuePOC1"],["QueuePOC2","2022-10-10 11:39","0","Successful","13/13","QueuePOC2"],["QueuePOC3","2022-10-10 11:39","0","Successful","13/13","QueuePOC3"],["QueuePOC4","2022-10-10 11:39","0","Faulted","13/19","QueuePOC4"]]
#process_data = pd.DataFrame(data, columns = ["Process","Projected End Time","Overshoot","Status","Progress","Graph"])

for x, Process in enumerate(process_data['Process']):
    col1, col2, col3, col4, col5, col6 = st.columns((2, 2, 2, 2, 2, 2))
    col1.write(process_data['Process'][x])  
    col2.write(process_data['Projected End Time'][x])  
    col3.write(process_data['Overshoot'][x])  
    col4.write(process_data['Status'][x])   
    col5.write(process_data['Progress'][x])
    #col6.write(process_data['Graph'][x])
    #disable_status = process_data['Graph'][x]  # flexible type of button
    button_type = process_data['Graph'][x]
    button_phold = col6.empty()  # create a placeholder
    do_action = button_phold.checkbox(label="Time Study", key=process_data['Graph'][x] )
    if do_action:
            #pass # do some action with row's data
            #button_phold.empty()  #  remove button
            QueueItemProcessingTimeDF = get_orchestrator_filtered_queue_items_processing_time.get_queue_item_processing_data(QueueDF,QueueItemDF,ProcessDF,process_data['Graph'][x])
            print((process_data['Graph'][x]))
            print(QueueItemProcessingTimeDF)
            if not (QueueItemProcessingTimeDF.empty):
                fig = px.line(QueueItemProcessingTimeDF, x="QueueItem", y="Processing Time", title="Queue Item Processing Time Plot")
                st.write(fig)
            else:
                st.write("""There is no Graph record for the selected Job""")
