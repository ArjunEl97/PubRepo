import json
import requests
def get_access_token(ConfigData):
    print("Get access token started")
    # Get Access Token
    URL = "https://account.uipath.com/oauth/token"
    payload = json.dumps({
      "grant_type": "refresh_token",
      "client_id": ConfigData["Client_Id"],
      "refresh_token": ConfigData["Refresh_Token"]
    })
    headers = {
      'Content-Type': 'application/json'
    }
    AuthResponse = requests.request("POST", URL, headers=headers, data=payload)
    json_AuthResponse = AuthResponse.json()
    access_token = json_AuthResponse['access_token']
    print(AuthResponse.text)
    print(access_token)
    return access_token
