import streamlit as st
import json

# Using the "with" syntax
with st.form(key='Business_Dashboard_Process_Form',clear_on_submit=True):
	text_input1 = st.text_input(label='Client ID')
	text_input2 = st.text_input(label='Refresh Token')
	text_input3 = st.text_input(label='URL')
	text_input4 = st.text_input(label='Folder Name')
	submit_button, cancel_button = st.columns([1,1])
	with submit_button:
            submit_button = st.form_submit_button(label='Submit')
	with cancel_button:
            cancel_button = st.form_submit_button(label='Cancel')

if (submit_button and (text_input1 == "" or text_input2 == "" or text_input3 == "" or text_input4 == "")):
    st.write("Please provide values to every field and then press submit button")

if (submit_button and text_input1 != "" and text_input2 != "" and text_input3 != "" and text_input4 != ""):
    st.write({text_input1},{text_input2},{text_input3},{text_input4})
    with open(r"C:\Users\User\AppData\Local\Programs\Python\Python310\BusinessProcessDashboardInputFile.json", 'r') as f:
        data = json.load(f)
        f.close()
        data["Client_Id"] = text_input1
        data["Refresh_Token"] = text_input2
        data["URL"] = text_input3
        data["Folder_Name"] = text_input4
    with open(r"C:\Users\User\AppData\Local\Programs\Python\Python310\BusinessProcessDashboardInputFile.json", 'w') as f:
        json.dump(data,f)
        f.close()
