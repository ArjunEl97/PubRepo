import pandas as pd
import plotly.express as px
from pyparsing import White
import streamlit as st

from PIL import Image
import numpy as np
# commenting for testing
#import business_process_dashboard
#import get_orchestrator_filtered_queue_items_processing_time

def custom_css(file_path:str):
    with open(file_path) as f:
        st.markdown("<style>{}</style>".format(f.read()),unsafe_allow_html = True)
 
def filter_table(key:str,data:pd.DataFrame) -> pd.DataFrame():
    # Return the filtered data based on the option selected
    filter_data = data[data["Process"] == key]
    if key == "All":
        filter_data = data
    return filter_data


def display_datatable(data:pd.DataFrame):
    # Display the dataframe passed to the calling streamlit element
    dataframe_container = st.container()
    with dataframe_container:
        hide_table_row_index = """
            <style>
            thead tr th:first-child {display:none}
            tbody th {display:none}
            </style>
            """
# Inject CSS with Markdown
        st.markdown(hide_table_row_index, unsafe_allow_html=True)
        st.table(filter_data.style.apply(highlighter, axis=None))
        #st.table(data)
        #AgGrid(data)
 
def display_counts(data:pd.DataFrame,col_name:str,subheader_name:str):
    # Display the counts of column values passed to the calling streamlit element
    count_container = st.container()
    with count_container:
        st.subheader(subheader_name)
        for val in data[col_name].unique():
            st.metric(label = val,value = len(data[data[col_name] == val]))
 
def display_bar(data:pd.DataFrame,x_col:str,y_col:str,subheader_name:str):
    # Display a bar chart based on dataframe and columns passed to the calling streamlit element
    bar_container = st.container()
    with bar_container:
        st.subheader(subheader_name)
        st.plotly_chart(px.bar(data_frame = data,x = x_col,y = y_col))
 
def display_pie(data:pd.DataFrame,col_name:str,subheader_name:str):
    # Display a pie chart based on dataframe and columns passed to the calling streamlit element
    name = data[col_name].sort_values().unique()
    runs = []
    for val in name:
        runs.append(len(data[data[col_name] == val]))
    pie_container = st.container()
    with pie_container:
        st.subheader(subheader_name)
        st.plotly_chart(px.pie(data_frame = data,names = name,values = runs,width=350,height=350))

def highlighter(x):
    # initialize default colors
    color_codes = pd.DataFrame('', index=x.index, columns=x.columns)
    # set Check color to red if consumption exceeds threshold green otherwise
    for col in x.columns:
        color_codes[col] = np.where(x['Overshoot'] > "0", 'background-color:#FFBF00;color:black;','')

        
    return color_codes

def make_clickable(url, name):
    url = "https://www.google.com"
    return st.markdown('<a href="{}" rel="noopener noreferrer" target="_blank">{}</a>'.format(url, name),unsafe_allow_html=True)
    #return '<a href="{}" rel="noopener noreferrer" target="_blank">{}</a>'.format(url, name)

def samplegraph():
    df = pd.DataFrame({'pig': [20, 18, 489, 675, 1776],'horse': [4, 25, 281, 600, 1900]}, index=[1990, 1997, 2003, 2009, 2014])
    lines = px.line(df,x="pig",y="horse",title="Queue Item Processing Time Plot", width=350,height=350)
    st.write(lines)

#----main Code-----#
st.set_page_config(page_title="Business Process Dashboard",layout="wide",initial_sidebar_state="collapsed")
custom_css(r"DashboardCss.css")
st.markdown('<style>body{background-color:#c0c0c0 !important;}</style>',unsafe_allow_html=True)
with st.container():
    title_col1,title_col2,title_col3 = st.columns([2 ,8,3])
    image = Image.open(r"slk-LOGO_Black.png")
    title_col1.image(image)
    title_col2.header("Business Process Dashboard")

# Brief Description about what to be done on this screen
#desc_cont = st.container()
#desc_cont.write("""This page will show the different processes that are running in the Orchestrator""")

with st.container():
    cols1,time_selector,cols4, process_selector,cols5 = st.columns([0.5,5.5,0.1,5.5,0.5])
    filter_container = st.container()
    with filter_container:
        with time_selector:
            time_selected = st.selectbox(label = "Select time here",options = ['None','1','2','5','12','24'])
#commenting for testing
#if time_selected == "None":
    #process_data, QueueDF, QueueItemDF, ProcessDF = business_process_dashboard.business_process_dashboard("100")
#if time_selected != "None":
    #st.write({time_selected})
    #process_data = business_process_dashboard.business_process_dashboard(time_selected)

#data for testing
data = [["QueuePOC1","2022-10-10 11:39","1","Running","1/13"],["QueuePOC2","2022-10-10 11:39","0","Successful","13/13"],["QueuePOC3","2022-10-10 11:39","1","Successful","13/13"],["QueuePOC4","2022-10-10 11:39","0","Faulted","13/19"],["QueuePOC5","2022-10-10 11:39","0","Running","1/13"],["QueuePOC6","2022-10-10 11:39","1","Successful","13/13"],["QueuePOC7","2022-10-10 11:39","0","Successful","13/13"],["QueuePOC8","2022-10-10 11:39","0","Faulted","13/19"]]
process_data = pd.DataFrame(data, columns = ["Process","Projected End Time","Overshoot","Status","Progress"])

with st.container():
    if process_data.empty:
        display_msg = st.container()
        display_msg.write("""There are no Job record in the selected time""")
    else:
        options = process_data["Process"].sort_values().unique()
        options = np.insert(options,0,"All")
        with process_selector:
            process_selected = st.selectbox(label = "Select process here",options = options)
        #display_area = st.container()
        # Display the data from table for selected option
        filter_data = filter_table(process_selected,process_data)
        #filter_data['Overshoot'] = filter_data.style.apply(lambda x: make_clickable(x['Process'], x['Overshoot']), axis=1)
        #st.dataframe(filter_data.style.apply(highlight_Status, axis=1))
        #st.dataframe(filter_data.style.applymap(color_Status, subset=['Status']))
        # apply highlighter to df
        #st.dataframe(filter_data.style.apply(highlighter, axis=None))

        with st.container():
            col1,tablecol,col3,graphcol,col5 = st.columns([0.5,7,0.5,3.5,0.5])
            with tablecol:
                with st.container():
                    #st.dataframe(filter_data.style.apply(highlighter, axis=None))
                    display_datatable(filter_data)
            with graphcol:
                display_pie(filter_data,"Status","status in total runs")
                samplegraph()
            #AgGrid(filter_data)     
        # Display the first set graphs
        #with st.container():
            #graphcol1,graphcol2,graphcol3,graphcol4,graphcol5=st.columns([1,9,1,9,1])
            #with graphcol2:
                #display_pie(filter_data,"Progress","Proportion of process")
            #with graphcol4:
                #display_pie(filter_data,"Status","Proportion of status in total runs")

# Code to get queueitem processing table
# process name is hard coded - "QueuePOC4" - should get from table when clicked
# commenting for testing
#QueueItemProcessingTimeDF = get_orchestrator_filtered_queue_items_processing_time.get_queue_item_processing_data(QueueDF,QueueItemDF,ProcessDF,"QueuePOC4")
#QueueItemProcessingTimeDF = business_process_dashboard.get_queue_item_processing_data("100","QueuePOC4")
#print(QueueItemProcessingTimeDF)