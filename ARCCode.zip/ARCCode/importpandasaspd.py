import pandas as pd
import plotly.express as px
from pyparsing import White
import streamlit as st
from st_aggrid import AgGrid
from PIL import Image
import numpy as np

df = pd.DataFrame({
    'name': ['stackoverflow', 'gis stackexchange', 'meta stackexchange'],
    'url': ['https://stackoverflow.com', 'https://gis.stackexchange.com/', 'https://meta.stackexchange.com']
})

#def make_clickable(url, name):
    #return st.markdown('<a href="{}" rel="noopener noreferrer" target="_blank">{}</a>'.format(url, name),unsafe_allow_html=True)

url = "https://google.co.in"
df['url'] = df.style.apply(lambda x: '<a href="{}" rel="noopener noreferrer" target="_blank">{}</a>'.format(url, df['name']), axis=1)
st.dataframe(df)
