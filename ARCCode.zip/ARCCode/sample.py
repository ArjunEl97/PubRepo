import pandas as pd
import plotly.express as px
from pyparsing import White
import streamlit as st

from PIL import Image
import numpy as np


def samplegraph():
    return st.error("dd")
    #dfs = pd.DataFrame({'pig': [20, 18, 489, 675, 1776],'horse': [4, 25, 281, 600, 1900]}, index=[1990, 1997, 2003, 2009, 2014])
    #lines = px.line(dfs,x="pig",y="horse",title="Queue Item Processing Time Plot", width=350,height=350)
    #return lines



data = [dict(name='Google', url='http://www.google.com'),
        dict(name='Stackoverflow', url='http://stackoverflow.com')]
df = pd.DataFrame(data)

def make_clickable(link):
    lines = samplegraph()
    return f'<a href="www.google.com">{link}</a>'#f'<button type="button" onclick={samplegraph()}>Click Me!</button>'

htmlstring = '<div class="alert alert-success">  <strong>Success!</strong> Indicates a successful or positive action.</div>'

df['url'] = df['url'].apply(make_clickable)
df = df.to_html(escape=False)
st.write(df, unsafe_allow_html=True)
