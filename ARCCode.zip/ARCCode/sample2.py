import streamlit as st
import streamlit.components.v1 as components

import pandas as pd
import plotly.express as px
from pyparsing import White
import streamlit as st

from PIL import Image
import numpy as np


def graph():
    df = pd.DataFrame({'pig': [20, 18, 489, 675, 1776],'horse': [4, 25, 281, 600, 1900]}, index=[1990, 1997, 2003, 2009, 2014])
    lines = px.line(df,x="pig",y="horse",title="Queue Item Processing Time Plot", width=350,height=350)

    st.write(lines)
    return lines

"""def samplegraph():
    display = st.button(label="axxsaxsx",key="asx")
    return display"""

data = [dict(name='Google', url='http://www.google.com')]
df = pd.DataFrame(data)
df["Button"] = list((st.button("Button1",key = "Button1"),st.button("Button2",key = "Button2")))

def make_clickable(link):
    lines = st.button(label="axxsaxsx",key=link)
    st.write(lines)
    return lines

df['url'] = df['url'].apply(make_clickable)
df = df.to_html(escape=False)
st.write(df, unsafe_allow_html=True)
sad= make_clickable('gffhg')
if(sad):
    graph()

# bootstrap 4 collapse example
components.html(
    """
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <div id="accordion">
      <div class="card">
        <div class="card-header" id="headingOne">
          <h5 class="mb-0">
            <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Collapsible Group Item #1
            </button>
          </h5>
        </div>
        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
          <div class="card-body">
            Collapsible Group Item #1 content
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header" id="headingTwo">
          <h5 class="mb-0">
            <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Collapsible Group Item #2
            </button>
          </h5>
        </div>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
          <div class="card-body">
            Collapsible Group Item #2 content
          </div>
        </div>
      </div>
    </div>
    """,
    height=600,
)

""" def graph():
    df = pd.DataFrame({'pig': [20, 18, 489, 675, 1776],'horse': [4, 25, 281, 600, 1900]}, index=[1990, 1997, 2003, 2009, 2014])
    lines = px.line(df,x="pig",y="horse",title="Queue Item Processing Time Plot", width=350,height=350)
    
    st.write(lines)
    return lines
def asdsadasd():
    return "dfsdfssdfdsfsdf"
def samplegraph():
    display = st.button(label="axxsaxsx",on_click=graph(),key="asx")
    return display
    

if(st.button('axxsaxsx')):
    result=samplegraph()
    st.write(result) """