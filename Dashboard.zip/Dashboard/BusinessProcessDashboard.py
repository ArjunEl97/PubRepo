import pandas as pd
import plotly.express as px
from pyparsing import White
import streamlit as st
from st_aggrid import AgGrid
from PIL import Image
import numpy as np
#commenting out for testing
#import business_process_dashboard

def custom_css(file_path:str):
    with open(file_path) as f:
        st.markdown("<style>{}</style>".format(f.read()),unsafe_allow_html = True)
 
def page_header(pg_ttl:str,pg_icn:str,pg_lyt:str,css_file_path = r"DashboardCss.css"):
    # Set up the webpage for mainpage
    st.set_page_config(page_title = pg_ttl,page_icon = pg_icn,layout = pg_lyt)
    custom_css(css_file_path)
 
    # Create the space for logo, app header and navigation buttons
    title_col1,title_col2,title_col3 = st.columns([2 ,7,3])
    image = Image.open(r"slk-LOGO_purple.png")
    title_col1.image(image)
    title_col2.header("Business Process Dashboard")
    # title_col3 will have the buttons to navigate to other pages
 
def filter_table(key:str,data:pd.DataFrame) -> pd.DataFrame():
    # Return the filtered data based on the option selected
    filter_data = data[data["Process"] == key]
    if key == "All":
        filter_data = data
    return filter_data
 
def display_datatable(data:pd.DataFrame):
    # Display the dataframe passed to the calling streamlit element
    dataframe_container = st.container()
    with dataframe_container:
        AgGrid(data)
 
def display_counts(data:pd.DataFrame,col_name:str,subheader_name:str):
    # Display the counts of column values passed to the calling streamlit element
    count_container = st.container()
    with count_container:
        st.subheader(subheader_name)
        for val in data[col_name].unique():
            st.metric(label = val,value = len(data[data[col_name] == val]))
 
def display_bar(data:pd.DataFrame,x_col:str,y_col:str,subheader_name:str):
    # Display a bar chart based on dataframe and columns passed to the calling streamlit element
    bar_container = st.container()
    with bar_container:
        st.subheader(subheader_name)
        st.plotly_chart(px.bar(data_frame = data,x = x_col,y = y_col))
 
def display_pie(data:pd.DataFrame,col_name:str,subheader_name:str):
    # Display a pie chart based on dataframe and columns passed to the calling streamlit element
    name = data[col_name].sort_values().unique()
    runs = []
    for val in name:
        runs.append(len(data[data[col_name] == val]))
    pie_container = st.container()
    with pie_container:
        st.subheader(subheader_name)
        st.plotly_chart(px.pie(data_frame = data,names = name,values = runs,width=500,height=500))
 
# ---- Main Code ----

page_header("Business Process Dashboard",":process:","wide",r"DashboardCss.css")
# Brief Description about what to be done on this screen
desc_cont = st.container()
desc_cont.write("""This page will show the different processes that are running in the Orchestrator""")

time_selector, process_selector = st.columns([1,1])
filter_container = st.container()
with filter_container:
    with time_selector:
        time_selected = st.selectbox(label = "Select time here",options = ['None','1','2','5','12','24'])
#commenting out for testing
#if time_selected == "None":
    #process_data = business_process_dashboard.business_process_dashboard("250")
#if time_selected != "None":
    #st.write({time_selected})
    #process_data = business_process_dashboard.business_process_dashboard(time_selected)

#for testing bar graph, remove later
data = [["QueuePOC1","2022-10-10 11:39","0","Running",13,"1/13"],["QueuePOC2","2022-10-10 11:39","0","Successful",13,"13/13"],["QueuePOC3","2022-10-10 11:39","0","Successful",13,"13/13"],["QueuePOC4","2022-10-10 11:39","0","Faulted",13,"13/19"]]
process_data = pd.DataFrame(data, columns = ["Process","Projected End Time","Overshoot","Status","Items","Progress"])


if process_data.empty:
    display_msg = st.container()
    display_msg.write("""There are no Job record in the selected time""")
else:
    options = process_data["Process"].sort_values().unique()
    options = np.insert(options,0,"All")
    with process_selector:
        process_selected = st.selectbox(label = "Select process here",options = options)
    display_area = st.container()
    # Display the data from table for selected option
    filter_data = filter_table(process_selected,process_data)
    with display_area:
        AgGrid(filter_data)     
    # Display the first set graphs
    graph_col1,graph_col2 = st.columns(2) 
    # Display the runs for the selected process
    with graph_col1:
        #display_counts(filter_data,"Status","Runs per status")
        #display_bar(filter_data, "Status", "Process", "Process per Status")
        display_pie(filter_data,"Progress","Proportion of process")
    # Display the number of each status
    with graph_col2:
        display_pie(filter_data,"Status","Proportion of status in total runs")
        